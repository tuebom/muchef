<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<h1>Users - Delete</h1>
