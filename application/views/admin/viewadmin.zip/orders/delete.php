<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<h1>Inventory - Delete</h1>
