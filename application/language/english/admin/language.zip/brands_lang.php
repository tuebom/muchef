<?php
/**
 * @package	CodeIgniter
 * @author	domProjects Dev Team
 * @copyright   Copyright (c) 2015, domProjects, Inc. (http://domProjects.com/)
 * @license http://opensource.org/licenses/MIT	MIT License
 * @link    http://domProjects.com
 * @since	Version 1.0.0
 * @filesource
 */
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['brands_name']        = 'Brand Name';
$lang['brands_action']      = 'Action';
$lang['brands_edit_brand']  = 'Edit brand';
$lang['brands_create']      = 'New brand';
